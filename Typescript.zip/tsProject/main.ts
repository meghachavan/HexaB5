//Barrel concept--Add index.ts file in each folder and add all export classes over there...
//like index.ts in model and services folder

import {ProductService, EmployeeService, UserService} from './services';
import {Product, Employee,User} from './models'

let empSvc:EmployeeService=new EmployeeService();
let employees:Employee[]=empSvc.getEmployees();

let productSvc:ProductService=new ProductService();
let products:Product[]=productSvc.getProducts();

let userSvc:UserService=new UserService();
let users:User[]=userSvc.getUser();