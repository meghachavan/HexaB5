export class EmployeeService{
    getEmployees():any{
        ///TODO:get list of employees
    }
}