export class UserService
{
    getUser():any{
        ///TODO:get list of users
    }

    validateUser(username:string, password:string):boolean{
        ///TODO:validate user
        return false;
    }
}