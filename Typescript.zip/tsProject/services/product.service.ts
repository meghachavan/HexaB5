export class ProductService{
    getProducts():any{
        ///TODO:get list of products
    }

    getProductById(id:number){
        ///search by id and return product
    }
}