class Employee{
    name:string ="";
    age:number=0;
    dateOfJoin:Date=new Date();
    salary:number=0;
    isMarried:boolean=false;
}

var emp:Employee = new Employee();
emp.name="Megha";
emp.age = 20;
emp.salary = 50000;
emp.dateOfJoin=new Date(2019,7,22);
emp.isMarried=true;

console.log(JSON.stringify(emp));