//import {sum,substract,multiply} from "./file1" 
import * as calculator from "./file1"

let a=20, b=5;
//let total=sum(a,b);
let total = calculator.sum(a,b);
console.log(total);

//let diff=substract(a,b);
let diff= calculator.substract(a,b);
console.log(diff);

//let product=multiply(a,b);
let product= calculator.multiply(a,b);
console.log(product);