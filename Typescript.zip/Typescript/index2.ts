interface Student
{
    id:number;
    name:string;
    age?:number;    //optional or nullable membes
    totalMark:number;
}

let student1:Student={
    id:20,
    name:"Ajay",
    age:15,
    totalMark:250    
}
let student2:Student={
    id:21,
    name:"Ovi",
    //age:10,
    totalMark:500
}

console.log(student1);