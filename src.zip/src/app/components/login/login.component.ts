import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  constructor(private fb: FormBuilder, private userSvc: UserService, private router: Router) {
    this.loginForm = this.fb.group({
      username: ["", Validators.required],
      password: ["", Validators.compose([Validators.required, Validators.minLength(8)])]

    });
  }

  ngOnInit() {
  }

  public get Username() {
    return this.loginForm.controls["username"];
  }

  public get Password() {
    return this.loginForm.controls["password"];
  }

  login() {
    if (this.loginForm.valid) {
      let username = this.loginForm.value.username;
      let password = this.loginForm.value.password;
      this.userSvc.getUser(username, password)
        .subscribe(
          result => {
            if (result.length > 0) {
              this.userSvc.saveUserState(result[0]);
              this.router.navigate(['/']);
            } else {
              alert("Invalid user or password.");
            }
          },
          err => {
            alert("Error..");
          }
        )
    } else {
      alert("Invalid username or password.");
    }
  }

}
