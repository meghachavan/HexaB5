import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/user';


@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  userForm: FormGroup;
  constructor(private fb: FormBuilder, private userSvc: UserService) {
    this.userForm = this.fb.group({
      username: ["", Validators.required],
      password: ["", Validators.compose([Validators.required, Validators.minLength(8)])],
      fullname: ["", Validators.required],
      email: ["", Validators.compose([Validators.required, Validators.email])]
    });
  }

  ngOnInit() {
  }

  public get Username() {
    return this.userForm.controls["username"];
  }

  public get Password() {
    return this.userForm.controls["password"];
  }

  public get Fullname() {
    return this.userForm.controls["fullname"];
  }

  public get Email() {
    return this.userForm.controls["email"];
  }


  register() {
    if (this.userForm.valid) {
      let user: User = this.userForm.value;
      user.role= "user";
      this.userSvc.addUser(user)
        .subscribe(
          result => {
            console.log(result);
            alert("Registration successfull....");
          },
          err => {
            alert("Error in register user..");
          }

        );
    } else {
      alert("Invalid form data");
    }
  }

}
