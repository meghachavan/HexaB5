import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable, BehaviorSubject } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
   userSubject: BehaviorSubject<any>;
   currentUser:Observable<any>;
  readonly API_URL = "http://localhost:63178/api/auth";
  constructor(private http: HttpClient) {
    this.userSubject=new BehaviorSubject<any>(JSON.parse(localStorage.getItem('user')));
    this.currentUser = this.userSubject.asObservable();
  }

  addUser(user: User): Observable<User> {
    return this.http.post<User>(`${this.API_URL}/register`, user);
  }

  getToken(loginData: any): Observable<any> {
    let url = `${this.API_URL}/token`;
    return this.http.post<any>(url, loginData);
  }

  saveUserState(user: User){
      localStorage.setItem("user",JSON.stringify(user));
      this.userSubject.next(user);
  }

  removeUserState(){
    localStorage.clear();
    this.userSubject.next(null);
  }

public get User() :  any {
  return this.userSubject.value;
}

  public get LoggedUser(): any {
    return this.userSubject.value;
  }
}
