import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  userSubject: BehaviorSubject<any>;
  currentUser:Observable<any>;
  readonly API_URL = "http://localhost:3000/users";
  constructor(private http: HttpClient) { 
    this.userSubject=new BehaviorSubject<any>(JSON.parse(localStorage.getItem('user')));
    this.currentUser = this.userSubject.asObservable();
  }

  addUser(user: User): Observable<User> {
    return this.http.post<User>(this.API_URL, user);
  }

  getUser(username: string, password: string): Observable<any> {
    let url = `${this.API_URL}?username=${username}&password=${password}`;
    return this.http.get<any>(url);
  }

  saveUserState(user: User){
      delete user.password;
      localStorage.setItem("user",JSON.stringify(user));
      this.userSubject.next(user);
  }

  removeUserState(){
    localStorage.clear();
    this.userSubject.next(null);
  }

  public get LoggedUser(): any {
    return this.userSubject.value;
  }
}
