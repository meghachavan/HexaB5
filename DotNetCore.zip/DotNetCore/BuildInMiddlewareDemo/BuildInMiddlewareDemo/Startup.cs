﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;

namespace BuildInMiddlewareDemo
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<CookiePolicyOptions>(options =>
            {
                // This lambda determines whether user consent for non-essential cookies is needed for a given request.
                options.CheckConsentNeeded = context => true;
                options.MinimumSameSitePolicy = SameSiteMode.None;
            });


            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            env.EnvironmentName = "Production";
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");

                //app.UseExceptionHandler(appBuilder =>
                //{
                //    appBuilder.Run(async (httpContext) =>
                //    {
                //        httpContext.Response.Headers.Add("Content-Type", "text/html");
                //        await httpContext.Response.WriteAsync("<h2>Error Occurred</h2>");
                //        await httpContext.Response.WriteAsync("<p>Internal Server Error - 500</p>");
                //    });
                //});
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            //app.UseDefaultFiles(); //http://localhost:1234/index.html -> directory is wwwroot and default file is index.html

            //var options = new DefaultFilesOptions();
            //options.DefaultFileNames.Clear();
            //options.DefaultFileNames.Add("hello.html");
            //app.UseDefaultFiles(options); //http://localhost:1234/files/hello.html -> directory is wwwroot and default file is hello.html

            ////To serve index.html from directory other than wwwroot
            //var fileOptions = new DefaultFilesOptions();
            ////fileOptions.DefaultFileNames.Clear();
            ////fileOptions.DefaultFileNames.Add("index.html");
            //fileOptions.RequestPath = "/files";
            //fileOptions.FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), "files"));
            //app.UseDefaultFiles(fileOptions); //dir is /files and default file is index.html



            ///*to get static files other than WWWROOT folder*/
            //app.UseStaticFiles(new StaticFileOptions()
            //{
            //    RequestPath = "/files",
            //    FileProvider=new PhysicalFileProvider(
            //        Path.Combine(Directory.GetCurrentDirectory(),"files")),
            //});

            app.UseFileServer(new FileServerOptions()
            {
                RequestPath = "/files",
                EnableDirectoryBrowsing = true,
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(), "files"))
            });
            //app.UseStaticFiles(); // For wwwroot

            ///*to display list of files available in "files" folder*/
            //app.UseDirectoryBrowser(new DirectoryBrowserOptions()
            //{                RequestPath = "/files",
            //    FileProvider = new PhysicalFileProvider(
            //        Path.Combine(Directory.GetCurrentDirectory(), "files"))
            //});

            app.UseCookiePolicy();

            app.UseMvcWithDefaultRoute();

            //app.UseMvc(routes =>
            //{
            //    //routes.MapRoute(
            //    //        name: "ProductRoute",
            //    //        template: "admin/products/{action=index}/{id?}");
            //    routes.MapRoute(
            //        name: "default",
            //        template: "{controller=Home}/{action=Index}/{id?}");
            //});
        }
    }
}
