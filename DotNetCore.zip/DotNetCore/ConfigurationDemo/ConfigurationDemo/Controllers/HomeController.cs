﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using ConfigurationDemo.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;

namespace ConfigurationDemo.Controllers
{
    public class HomeController : Controller
    {
        private IConfiguration configuration;
        private AppConfiguration appConfig;
        private AppConfiguration projectDetail;

        public HomeController(IConfiguration config, IOptions<AppConfiguration> options, IOptions<ProblemDetails> projectOptions)
        {
            configuration = config;
            this.appConfig = options.Value;
            //this.projectDetail = projectOptions;
        }
        public IActionResult Index()
        {
            //var company = configuration.GetValue<string>("CompanyName");
            //var location = configuration.GetValue<string>("Location");
            //var count = configuration.GetValue<int>("ParticipantCount");
            //var arch = configuration.GetValue<string>("PROCESSOR_ARCHITECTURE");
            //var userProfile = configuration.GetValue<string>("USERPROFILE");
            //var noOfProcessor = configuration.GetValue<int>("NUMBER_OF_PROCESSORS");

            ////var title = configuration.GetValue<string>("ProjectDetails:Title");

            //var project = configuration.GetSection("ProjectDetails");
            //var title = project["Title"];
            //var duration = project["Duration"];
            //var status = project["Status"];

            var companyname = appConfig.CompanyName;
            var location = appConfig.Location;
            var participantCount = appConfig.ParticipantCount;
            
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
