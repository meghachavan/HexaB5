﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using ServicesDemo.Models;
using ServicesDemo.Services;

namespace ServicesDemo.Controllers
{
    public class HomeController : Controller
    {
        private IDataManager dm;
        //private IConfiguration configuration;


        //public HomeController(NoSqlDataManager dataManager)
        public HomeController(IDataManager dataManager /*,IConfiguration config*/)        
        {
            this.dm = dataManager;
            //this.configuration = config;
        }
        public IActionResult Index([FromServices]IConfiguration configuration)
        {
            ViewBag.Message = dm.GetData();
            ViewBag.UserName = configuration.GetValue<string>("UserDetails:Name");
            ViewBag.Email = configuration.GetValue<string>("UserDetails:Email");
            ViewBag.Age = configuration.GetValue<int>("UserDetails:Age");
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
